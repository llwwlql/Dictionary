package reflex;

public class Test {

	public static void main(String[] args) throws Exception {
		// TODO �Զ����ɵķ������
		Propertyreflex pr=new Propertyreflex();
		MethodReflex mr=new MethodReflex();
		pr.Evaluate();
		mr.Evaluate();
	}
}
