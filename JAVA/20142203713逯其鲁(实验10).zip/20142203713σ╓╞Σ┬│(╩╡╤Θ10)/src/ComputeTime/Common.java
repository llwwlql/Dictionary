package ComputeTime;

public interface Common {
	public double speed();
}